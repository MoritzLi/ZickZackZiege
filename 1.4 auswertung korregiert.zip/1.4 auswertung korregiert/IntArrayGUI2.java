import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.Random;
import java.awt.color.*;

/**
 * GUI fuer das Projekt Zahlenliste
 * 
 * @author Dr. Oliver Heidbuechel
 * @version 2.0
 */
public class IntArrayGUI2 extends JFrame implements ActionListener
{
    private JButton neu;
    private JButton[][] b;
    private Einzelspiel e;
    private Spiel spiel;
    private JTextField tIndexI, tIndexJ;
    private JLabel[] l;
    private JTextField t[];
    private JLabel iIndexI, iIndexJ;
    int spielzug = 1;
    int spieleranzahl, feldgr;

    /**
     * Konstruktor fuer Objekte der Klasse IntArrayGUI
     */
    public IntArrayGUI2(int pspieleranzahl){
        feldgr = pspieleranzahl+3;
        spieleranzahl = pspieleranzahl;
        if(spieleranzahl ==1)
            feldgr++;
        setSize(feldgr*50+200, feldgr*50+100+75*spieleranzahl);
       setLocation(100, 100);
       JPanel folie = new JPanel();
       getContentPane().add(folie);
       folie.setBackground(Color.yellow);
       folie.setLayout(null);
       
       b = new JButton[feldgr][feldgr];
       if(spieleranzahl == 1){
           JLabel lIndexI = new JLabel("KI: ");
           lIndexI.setBounds(20, feldgr*50+40,30, 30);
           folie.add(lIndexI);
           JLabel lIndexJ = new JLabel("Du: ");
           lIndexJ.setBounds(20, feldgr*50+80, 30, 30);
           folie.add(lIndexJ);
           tIndexI = new JTextField("0");
           tIndexI.setBounds(60, feldgr*50+40, 30, 30);
           folie.add(tIndexI);
           tIndexJ = new JTextField("0");
           tIndexJ.setBounds(60, feldgr*50+80, 30, 30);
           folie.add(tIndexJ);
        }else{
            l = new JLabel[spieleranzahl];
            t = new JTextField[spieleranzahl];
            for(int i = 0; i < spieleranzahl; i++){
                l[i] = new JLabel(""+i);
                l[i].setBounds(20,feldgr*50+i*40,30,30);
                folie.add(l[i]);
                t[i] = new JTextField("0");
                t[i].setBounds(60,feldgr*50+i*40,30,30);
                folie.add(t[i]);
            }
        }
       
       
        int yKor = 0;
        for(int i = 0;i<feldgr;i++){
            int xKor = 0;
           for(int j = 0; j<feldgr;j++){
               b[i][j] = new JButton();
               b[i][j].setBounds(xKor,yKor,50,50);
               b[i][j].addActionListener(this);
               folie.add(b[i][j]);
               xKor = xKor+50;
               b[i][j].setBackground(Color.black);
            }
            yKor = yKor+50;
        }
        
       setVisible(true);
       if(spieleranzahl == 1){
            b[2][2].setBackground(Color.blue);
            e  = new Einzelspiel(1);
        }else{
            spiel = new Spiel(spieleranzahl);
        }
   }
   
    public void spiele(int x, int y){
        if(spielzug == 1){
            e.einzelspieler(1);
            e.feld.setze(e.getEinzelXKor(),e.getEinzelYKor(),1);
            spielzug = 3;
        }
        if(e.feld.leer(x,y)){
            e.feld.setze(x,y,2);
            e.einzelspieler(spielzug);
            e.feld.setze(e.getEinzelXKor(),e.getEinzelYKor(),1);
            spielzug = spielzug+2;
        }
        else 
            System.out.print("belegt");
    }
      

   /**
    * Reagiere auf Events!
    */
   public void actionPerformed (ActionEvent ev) {
      Object quelle = ev.getSource();
          if(spieleranzahl == 1){
            for(int i = 0;i<feldgr;i++){
               for(int j = 0; j<feldgr;j++){
                  if(quelle == b[i][j] && e.feld.leer(i,j)){
                      spiele(i,j);
                      b[i][j].setBackground(Color.red);
                      int x = e.getEinzelXKor();
                      int y = e.getEinzelYKor();
                      b[x][y].setBackground(Color.blue);
                      tIndexI.setText(""+e.feld.auswertung(1));
                      tIndexJ.setText(""+e.feld.auswertung(2));
                    }
                }
            }
        }else{
            for(int i = 0;i<feldgr;i++){
               for(int j = 0; j<feldgr;j++){
                  if(quelle == b[i][j] && spiel.feld.leer(i,j)){
                     int rest = spielzug % spieleranzahl;
                     spiel.spielen(i,j,spielzug);
                     switch(rest){
                         case 0:
                            b[i][j].setBackground(Color.magenta);
                            break;
                         case 1:
                            b[i][j].setBackground(Color.red);
                         break;
                         case 2:
                            b[i][j].setBackground(Color.blue);
                        break;
                        case 3: 
                            b[i][j].setBackground(Color.yellow);
                        break;
                        case 4: 
                            b[i][j].setBackground(Color.white);
                            break;
                        case 5:
                            b[i][j].setBackground(Color.orange);
                            break;
                        case 6:
                            b[i][j].setBackground(Color.green);
                            break;
                        case 7:
                            b[i][j].setBackground(Color.cyan);
                            break;
                        default:
                        break;
                    
                        
                        }
                        spielzug++;
                    }
                }
            }
        }
              if(spielzug >feldgr*feldgr && spieleranzahl > 1){
                spiel.list.toFirst();
                for(int i = 0; i < spieleranzahl; i++){
                    t[i].setText(""+spiel.list.getContent().getPunkte());
                    spiel.list.next();
                }
            }

   }

 
}