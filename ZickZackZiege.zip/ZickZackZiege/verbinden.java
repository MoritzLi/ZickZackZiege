public class verbinden
{
    // Instanzvariablen 
    DatabaseConnector verbi;
    /**
     * Konstruktor für Objekte der Klasse verbinden
     */
    public verbinden()
    {
        // ggf. Instanzvariable initialisieren
        verbi = new DatabaseConnector("172.16.0.52", 3306 , "zickzackziege" , "zzz", "zzz");

        System.out.println(verbi.getErrorMessage());
    }

    public void alleSpielerGeben(){
        verbi.executeStatement("SELECT * FROM spieler");
        QueryResult ergebnis = verbi.getCurrentQueryResult();
        String[][] Daten = ergebnis.getData();

        for(int i = 0; i < ergebnis.getRowCount(); i++){
            for(int u = 0; u < ergebnis.getColumnCount(); u++){
                System.out.print(Daten[i][u]+" ");
            }
            System.out.println();
        }
    }

    //     public void alleSchuelerInListe(){
    //         verbi.executeStatement("SELECT * FROM schueler");
    //         QueryResult ergebnis = verbi.getCurrentQueryResult();
    //         String[][] Daten = ergebnis.getData();
    //         String ids;
    //         int id;
    //         String vorname;
    //         String nachname;
    //         String alters;
    //         int alter; 
    //         for(int i = 0; i < ergebnis.getRowCount(); i++){
    //             ids = Daten[i][0];
    //             vorname = Daten[i][1];
    //             nachname = Daten[i][2];
    //             alters = Daten[i][3];
    //             id = Integer.parseInt(ids);
    //             alter = Integer.parseInt(alters);
    //             verwaltung.append(new Schueler(id,vorname,nachname,alter));
    //         }
    //     }

    public void spielerAnlegen(String name){
        String sql ="INSERT into spieler VALUES(null, '"+name+"')";
        verbi.executeStatement(sql);
        System.out.println(sql);
    }

    //     public void schuelerLoeschen(int id){
    //         String sql = " DELETE FROM schueler WHERE UserID = '"+id+"'";
    //         verbi.executeStatement(sql);
    //     }
}
