public class Spieler
{
    private int spielernr;
    private int punkte = 0;
    private String skin;


    public Spieler(int pSpielernr)
    {
        spielernr = pSpielernr;
    }
    
    public int getSpielernr(){
        return spielernr;
    }
    
    public void setPunkte(int pPunkte){
        punkte = pPunkte;
    }


}
