
public class Spiel
{
    int spieleranzahl;
    List<Spieler> list = new List();
    Feld feld;
    int einzelXKor;
    int einzelYKor;
    public Spiel(int pSpieleranzahl)
    {
       spieleranzahl = pSpieleranzahl;
       if(spieleranzahl == 1){
           einzelspieler();
        }else{
            feld = new Feld(spieleranzahl);
            for(int i = 1;spieleranzahl-i>=0;i++){
                Spieler spieler = new Spieler(i);
                list.append(spieler);
            }
        }
    }
    
    public int spielen(int xKor,int yKor,int spielzug){
        if(spielzug == 0)
            list.toFirst();
        if(feld.leer(xKor,yKor)){
            feld.setze(xKor,yKor,list.getContent().getSpielernr());
            if(list.hasAccess())
                list.next();
            else
                list.toFirst();
            spielzug++;
        }
        if(spielzug == (spieleranzahl+3)*(spieleranzahl+3)-1){
            list.toFirst();
            while(list.hasAccess()){
                list.getContent().setPunkte(feld.auswertung(list.getContent().getSpielernr()));
                list.next();
            }
            return -1; //spiel zuende
        }
        return spielzug;
    }
    public void einzelspieler(){
        Feld feld = new Feld(2);
        einzelXKor = 0; // Werte zuweisen, wo gesetzt werden soll
        einzelYKor = 0; 
        // im gui abwechselnd spielen mit vom spieler gewähltem x und y und danach mit von einzelspieler zugewiesenen x und y aufrufen
    }
    
    public int getEinzelXKor(){
        return einzelXKor;
    }
    
    public int getEinzelYKor(){
        return einzelYKor;
    }
    
    

}
